package com.infinite.service;

import com.infinite.model.OrderList;

public interface IOrderService {
	public OrderList addorder(OrderList orderlist);
}
